<<<<<<< HEAD
# QuillHive
=======
# QuillHive

> Where Creators Gather.

A production-grade creative platform for writers, poets, novelists, and
illustrators. QuillHive is a pnpm monorepo with a typed Express API, a
React + Vite web client, a shared Drizzle/Postgres schema, and a generated
typed API client.

---

## Repository layout

```
apps/
  api/          @workspace/api-server   — Express + Socket.IO + BullMQ
  web/          @workspace/quillhive    — React 18 + Vite + Tailwind + TipTap
  public-web/                           — Public marketing surface
features/
  quillhive/
    mockup-sandbox/                     — Component preview sandbox (Vite)
packages/
  utils/
    db/         @workspace/db           — Drizzle ORM schema + client
    api-spec/   @workspace/api-spec     — OpenAPI / contract source of truth
    api-zod/    @workspace/api-zod      — Shared zod request/response schemas
    api-client-react/                   — Generated typed React-Query hooks
scripts/                                — Build, codegen, and ops scripts
```

The repo is **strictly one root project**. New work belongs inside
`apps/`, `features/`, or `packages/` — never in a wrapper folder.

---

## Quick start

```bash
pnpm install
pnpm --filter @workspace/db push      # push schema to Postgres
pnpm dev                              # runs all workflows
```

Visit the web app via the Replit preview, or the API directly at
`/api/health`.

### Required environment

| Var            | Required | Notes                                              |
|----------------|----------|----------------------------------------------------|
| `DATABASE_URL` | yes      | Postgres connection string                          |
| `JWT_SECRET`   | prod     | ≥ 32 chars; dev falls back to a known dev secret    |
| `PORT`         | yes      | Provided by Replit per artifact                     |
| `APP_URL`      | no       | Used for OG/canonical URLs                          |
| `REDIS_URL`    | no       | If set, BullMQ workers run; otherwise jobs are skipped |
| `SENTRY_DSN`   | no       | Enables Sentry capture if `@sentry/node` is installed |

No domains or emails are hardcoded — everything is read from env.

---

## Architecture overview

- **Auth** — HMAC-SHA256 JWTs (`access` + `refresh`) signed with `JWT_SECRET`.
  Refresh tokens are persisted in `sessions` keyed by hashed JTI; access
  tokens are stateless. `loadCurrentUser` / `requireAuthTyped` provide a
  typed `AuthenticatedRequest` for handlers (see `apps/api/src/lib/auth-types.ts`).
- **Database** — Postgres via Drizzle ORM. Schema lives in
  `packages/utils/db/src/schema/*` and is exported as `@workspace/db/schema`.
  Push changes with `pnpm --filter @workspace/db push`.
- **API surface** — Express 5. Routes are mounted in
  `apps/api/src/routes/index.ts`; feature modules under
  `apps/api/src/features/*` follow a `routes / controller / service` split.
- **Realtime** — Socket.IO is initialized in `apps/api/src/lib/socket.ts`
  and used for notifications, mentions, and messaging.
- **Background jobs** — BullMQ + Redis when `REDIS_URL` is set. The worker
  boots from `lib/queue/worker.ts`. Without Redis the system degrades
  gracefully (warned in logs).
- **Trust & safety** — `features/trust/*` computes per-user trust scores
  and `reachMultiplier`. Login integrity is recorded into `login_events`
  on every successful auth.
- **Post versioning** — Every `updatePost` snapshots the prior content
  into `post_versions`. Owners and admins can browse via
  `GET /api/posts/:id/versions` and `GET /api/posts/:id/versions/:versionId`.
- **Observability** — Pino structured logs everywhere. Optional Sentry
  forwarding via `SENTRY_DSN` (no-op if unset).

---

## Useful endpoints

| Method | Path                                  | Purpose                              |
|--------|---------------------------------------|--------------------------------------|
| GET    | `/api/health`                         | Liveness                             |
| POST   | `/api/auth/login`                     | Login + records login event          |
| POST   | `/api/auth/logout`                    | Revoke current refresh token         |
| GET    | `/api/auth/sessions`                  | List my active sessions              |
| GET    | `/api/auth/login-activity`            | Last 5 login events                  |
| POST   | `/api/auth/sessions/logout-all`       | Revoke every session                 |
| GET    | `/api/posts`                          | Feed                                 |
| POST   | `/api/posts`                          | Create post                          |
| PATCH  | `/api/posts/:id`                      | Edit post (snapshots a version)      |
| GET    | `/api/posts/:id/versions`             | Version history (owner + admin)      |
| GET    | `/api/posts/:id/versions/:versionId`  | Full version content                 |
| GET    | `/api/mentions/search?q=`             | Username autocomplete                |
| POST   | `/api/mentions/parse`                 | Process @mentions for a post         |

A complete machine-readable contract lives in `packages/utils/api-spec`.

---

## Conventions

- **Type safety** — No `any` at module boundaries. Use
  `AuthenticatedRequest` / `getViewerId` / `loadCurrentUser` from
  `apps/api/src/lib/auth-types.ts`.
- **Sanitization** — All rich-text input goes through `lib/sanitize.ts`
  on the server *and* DOMPurify on the client.
- **Rate limiting & abuse** — Use `middleware/rateLimit` and
  `middleware/abuseProtection` for any new write endpoint.
- **Errors** — Throw `Error("Forbidden")` / `"Not found"` from services;
  controllers map them to status codes. Anything unhandled is captured
  by `attachErrorHandler` (logs + optional Sentry).

---

## Scripts

| Script                                          | What it does                  |
|-------------------------------------------------|-------------------------------|
| `pnpm dev`                                      | Starts all workflows          |
| `pnpm --filter @workspace/api-server typecheck` | TypeScript check (api)        |
| `pnpm --filter @workspace/quillhive typecheck`  | TypeScript check (web)        |
| `pnpm --filter @workspace/api-server test`      | Vitest unit tests (api)       |
| `pnpm --filter @workspace/db push`              | Apply Drizzle schema changes  |

---

## License

See `LICENSE` and `NOTICE` for details.
>>>>>>> 9825b9e (Initial commit)
