import { db } from "@workspace/db";
import { systemSettingsTable } from "@workspace/db/schema";

export const FEATURE_FLAG_KEYS = [
  // Core platform controls
  "registration_open",
  "maintenance_mode",
  "post_creation_enabled",
  "quick_posts_enabled",
  "ai_tools_enabled",
  // Content types
  "polls_enabled",
  "motion_enabled",
  "chains_enabled",
  "series_enabled",
  // Creator tools
  "highlights_enabled",
  "gallery_enabled",
  "embed_enabled",
  "ab_testing_enabled",
  "collections_enabled",
  "income_tracker_enabled",
  // Auth methods (beyond password + OAuth)
  "magic_link_enabled",
  "passkey_enabled",
  // Future (infrastructure ready, not launched)
  "tipping_enabled",
  "subscriptions_enabled",
  "podcast_enabled",
] as const;

export type FeatureFlagKey = (typeof FEATURE_FLAG_KEYS)[number];

// When a flag has no DB row, these are the defaults.
// Everything not listed here defaults to TRUE (enabled).
export const DEFAULT_FLAGS: Partial<Record<string, boolean>> = {
  motion_enabled:         false, // video hosting — cost + complexity
  chains_enabled:         false, // collaborative writing — Phase 2
  series_enabled:         false, // multi-part posts — Phase 2
  gallery_enabled:        false, // separate gallery — Phase 2
  embed_enabled:          false, // post embeds — Phase 2
  ab_testing_enabled:     false, // power user feature — Phase 2
  magic_link_enabled:     false, // simplify auth for launch
  passkey_enabled:        false, // WebAuthn — Phase 2
  income_tracker_enabled: false, // removed from launch nav
  collections_enabled:    false, // advanced library — Phase 2
  tipping_enabled:        false, // not built yet
  subscriptions_enabled:  false, // not built yet
  podcast_enabled:        false, // not built yet
};

interface CacheEntry {
  value: boolean;
  expiresAt: number;
}

const cache = new Map<string, CacheEntry>();
const TTL_MS = 60_000;

export async function reloadFeatureFlags(): Promise<void> {
  const rows = await db.select().from(systemSettingsTable);
  cache.clear();
  const expiresAt = Date.now() + TTL_MS;
  for (const row of rows) {
    if ((FEATURE_FLAG_KEYS as readonly string[]).includes(row.key)) {
      cache.set(row.key, { value: row.value === "true", expiresAt });
    }
  }
}

export async function isFeatureEnabled(key: string): Promise<boolean> {
  const cached = cache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const rows = await db.select().from(systemSettingsTable);
  const expiresAt = Date.now() + TTL_MS;

  for (const row of rows) {
    if ((FEATURE_FLAG_KEYS as readonly string[]).includes(row.key)) {
      cache.set(row.key, {
        value: row.value === "true",
        expiresAt,
      });
    }
  }

  // If still not in cache, use DEFAULT_FLAGS or true
  if (!cache.has(key)) {
    const defaultVal = DEFAULT_FLAGS[key] ?? true;
    cache.set(key, { value: defaultVal, expiresAt });
  }

  return cache.get(key)?.value ?? (DEFAULT_FLAGS[key] ?? true);
}

export async function getAllFeatureFlags(): Promise<Record<FeatureFlagKey, boolean>> {
  const rows = await db.select().from(systemSettingsTable);
  // Start with defaults
  const map: Record<string, boolean> = {};
  for (const k of FEATURE_FLAG_KEYS) {
    map[k] = DEFAULT_FLAGS[k] ?? true;
  }
  // Override with DB values
  for (const row of rows) {
    if ((FEATURE_FLAG_KEYS as readonly string[]).includes(row.key)) {
      map[row.key] = row.value === "true";
    }
  }
  return map as Record<FeatureFlagKey, boolean>;
}
