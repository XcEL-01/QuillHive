import { useEffect } from "react";

export function usePageTitle(title?: string, unread?: number) {
  useEffect(() => {
    const base = title ? `${title} — QuillHive` : "QuillHive";
    document.title = unread && unread > 0 ? `(${unread}) ${base}` : base;
    return () => {
      document.title = "QuillHive";
    };
  }, [title, unread]);
}
