import { useQuery } from "@tanstack/react-query";

export type FeatureFlags = Record<string, boolean>;

// Fetches public feature flags from /api/features
// No auth required — this is a public endpoint
export function useFeatureFlags(): FeatureFlags {
  const { data } = useQuery<FeatureFlags>({
    queryKey: ["feature-flags"],
    queryFn: async () => {
      const res = await fetch("/api/features");
      if (!res.ok) return {};
      return res.json();
    },
    staleTime: 60_000,
    gcTime: 5 * 60_000,
    // Don't throw on error — gracefully return empty
    throwOnError: false,
  });
  return data ?? {};
}

// Hook for a single flag.
// Unknown flags default to true (show everything).
export function useFeature(flag: string): boolean {
  const flags = useFeatureFlags();
  return flags[flag] ?? true;
}
