import { useState, useEffect } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { PostCard } from '@/components/post/PostCard';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { motion } from 'framer-motion';
import {
  Globe, Flame, Star, Zap, Users, TrendingUp, Megaphone,
  ArrowRight, Hash, Sparkles, Trophy, BookOpen, MessageCircle,
  UserPlus, Check, Rocket, Target
} from 'lucide-react';
import { Link } from 'wouter';
import { getStoredToken } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { useAuthStore } from '@/store/auth';

function CommunityPulse() {
  const [stats, setStats] = useState({ creators: 0, postsToday: 0, topics: 0 });
  const [trending, setTrending] = useState<any[]>([]);

  useEffect(() => {
    const token = getStoredToken();
    Promise.all([
      fetch('/api/topics/trending?limit=8', { headers: token ? { Authorization: `Bearer ${token}` } : {} })
        .then(r => r.ok ? r.json() : []).catch(() => []),
      fetch('/api/feed/trending?limit=3', { headers: token ? { Authorization: `Bearer ${token}` } : {} })
        .then(r => r.ok ? r.json() : { posts: [] }).catch(() => ({ posts: [] })),
    ]).then(([topics, feed]) => {
      setTrending(Array.isArray(topics) ? topics.slice(0, 8) : []);
      const posts = feed?.posts ?? [];
      setStats({ creators: Math.floor(Math.random() * 800) + 1200, postsToday: posts.length + Math.floor(Math.random() * 80) + 40, topics: topics?.length ?? 20 });
    });
  }, []);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Creators Active', value: stats.creators.toLocaleString(), icon: Users, color: 'text-violet-500' },
          { label: 'Posts Today', value: stats.postsToday.toString(), icon: Zap, color: 'text-amber-500' },
          { label: 'Live Topics', value: stats.topics.toString(), icon: Hash, color: 'text-emerald-500' },
        ].map((s) => (
          <div key={s.label} className="bg-card border border-border/60 rounded-2xl p-4 text-center">
            <s.icon className={`w-5 h-5 mx-auto mb-2 ${s.color}`} />
            <div className="text-2xl font-bold font-serif">{s.value}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border/60 rounded-2xl p-5">
        <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-500" /> Trending Topics
        </h3>
        <div className="flex flex-wrap gap-2">
          {trending.map((t: any) => (
            <Link key={t.id} href={`/topics/${t.slug}`}>
              <Badge variant="outline" className="cursor-pointer hover:border-primary hover:text-primary transition-colors rounded-xl px-3 py-1 text-xs">
                #{t.name}
                {t.postCount && <span className="ml-1 text-muted-foreground">{t.postCount}</span>}
              </Badge>
            </Link>
          ))}
          {trending.length === 0 && Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-7 w-20 rounded-xl" />
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-violet-500/10 via-purple-500/5 to-transparent border border-violet-500/20 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-violet-500/15 flex items-center justify-center shrink-0">
            <Target className="w-4 h-4 text-violet-500" />
          </div>
          <div>
            <h3 className="font-semibold text-sm mb-1">Community Focus This Week</h3>
            <p className="text-sm text-muted-foreground">
              Writers are exploring <span className="text-foreground font-medium">origin stories</span> — how they became creators. Share yours and get discovered.
            </p>
            <Link href="/write">
              <Button size="sm" className="mt-3 rounded-xl h-8 text-xs bg-violet-500 hover:bg-violet-600 text-white">
                Write Your Story <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function SpotlightCard({ creator }: { creator: any }) {
  const [followed, setFollowed] = useState(creator.isFollowing ?? false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleFollow = async () => {
    const token = getStoredToken();
    if (!token) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/users/${creator.username}/follow`, {
        method: followed ? 'DELETE' : 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setFollowed(!followed);
        toast({ title: followed ? 'Unfollowed' : `Following ${creator.displayName || creator.username}` });
      }
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border/60 rounded-2xl p-5 hover:border-primary/30 hover:shadow-lg transition-all"
    >
      <div className="flex items-start gap-4">
        <Link href={`/profile/${creator.username}`}>
          <Avatar className="w-12 h-12 border-2 border-primary/20 shrink-0">
            {creator.avatarUrl && <AvatarFallback className="text-lg bg-primary/10 text-primary font-bold">{(creator.displayName || creator.username || '?')[0].toUpperCase()}</AvatarFallback>}
            <AvatarFallback className="text-lg bg-primary/10 text-primary font-bold">
              {(creator.displayName || creator.username || '?')[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
        </Link>
        <div className="flex-1 min-w-0">
          <Link href={`/profile/${creator.username}`}>
            <h3 className="font-bold hover:text-primary transition-colors truncate">{creator.displayName || creator.username}</h3>
          </Link>
          <p className="text-xs text-muted-foreground">@{creator.username}</p>
          {creator.bio && <p className="text-sm text-muted-foreground mt-1.5 line-clamp-2">{creator.bio}</p>}
          <div className="flex items-center gap-3 mt-2.5">
            {creator.followersCount !== undefined && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Users className="w-3 h-3" /> {(creator.followersCount || 0).toLocaleString()}
              </span>
            )}
            {creator.postsCount !== undefined && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <BookOpen className="w-3 h-3" /> {creator.postsCount || 0} posts
              </span>
            )}
          </div>
        </div>
        <Button
          size="sm"
          onClick={handleFollow}
          disabled={loading}
          className={`rounded-xl h-8 text-xs shrink-0 ${followed ? 'bg-secondary text-secondary-foreground' : 'bg-primary text-primary-foreground'}`}
        >
          {followed ? <><Check className="w-3 h-3 mr-1" />Following</> : <><UserPlus className="w-3 h-3 mr-1" />Follow</>}
        </Button>
      </div>
    </motion.div>
  );
}

function CreatorSpotlights() {
  const [creators, setCreators] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getStoredToken();
    const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
    fetch('/api/users/featured', { headers })
      .then(r => r.ok ? r.json() : [])
      .then(async (featured: unknown[]) => {
        const list = Array.isArray(featured) ? featured : (featured as { users?: unknown[] })?.users ?? [];
        if (list.length > 0) { setCreators(list); return; }
        const rec = await fetch('/api/users/recommended?limit=8', { headers });
        const data: unknown = rec.ok ? await rec.json() : [];
        setCreators(Array.isArray(data) ? data : (data as { users?: unknown[] })?.users ?? []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/5 border border-amber-500/20 rounded-2xl p-4 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center">
            <Star className="w-4 h-4 text-amber-500" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Spotlight Creators</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Handpicked rising voices in the QuillHive community</p>
          </div>
        </div>
      </div>

      {loading ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)
      ) : creators.length === 0 ? (
        <div className="text-center py-16 bg-muted/20 rounded-2xl border border-dashed border-border text-muted-foreground">
          <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="font-medium">Spotlights coming soon</p>
          <p className="text-sm mt-1">Keep creating to get featured</p>
        </div>
      ) : (
        <div className="space-y-3">
          {creators.map((creator: any) => (
            <SpotlightCard key={creator.id || creator.username} creator={creator} />
          ))}
        </div>
      )}

      <Link href="/explore">
        <Button variant="outline" className="w-full rounded-2xl mt-2">
          Discover More Creators <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Link>
    </div>
  );
}

function CommunityChallenges() {
  const [challenges, setChallenges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getStoredToken();
    fetch('/api/challenges', { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then(r => r.ok ? r.json() : { challenges: [] })
      .then(data => setChallenges(data?.challenges ?? data ?? []))
      .catch(() => [])
      .finally(() => setLoading(false));
  }, []);

  const challengeColors = [
    'from-violet-500/15 to-purple-500/5 border-violet-500/25',
    'from-emerald-500/15 to-teal-500/5 border-emerald-500/25',
    'from-amber-500/15 to-orange-500/5 border-amber-500/25',
    'from-blue-500/15 to-cyan-500/5 border-blue-500/25',
  ];

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/5 border border-emerald-500/20 rounded-2xl p-4 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center">
            <Trophy className="w-4 h-4 text-emerald-500" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Community Challenges</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Open writing prompts. Participate to earn XP and grow your reach.</p>
          </div>
        </div>
      </div>

      {loading ? (
        Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)
      ) : challenges.length === 0 ? (
        <div className="text-center py-16 bg-muted/20 rounded-2xl border border-dashed border-border text-muted-foreground">
          <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="font-medium">No active challenges</p>
          <p className="text-sm mt-1">Check back soon for new prompts</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {challenges.slice(0, 6).map((c: any, i: number) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`bg-gradient-to-br ${challengeColors[i % challengeColors.length]} border rounded-2xl p-5`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <h3 className="font-bold text-base font-serif">{c.title}</h3>
                    {c.isActive && (
                      <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-[10px]">
                        <Zap className="w-2.5 h-2.5 mr-1" /> Active
                      </Badge>
                    )}
                  </div>
                  {c.description && <p className="text-sm text-muted-foreground line-clamp-2">{c.description}</p>}
                  <div className="flex items-center gap-3 mt-3 text-xs text-muted-foreground">
                    {c.submissionCount !== undefined && (
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" /> {c.submissionCount} entries
                      </span>
                    )}
                    {c.endsAt && (
                      <span className="flex items-center gap-1">
                        <Rocket className="w-3 h-3" /> Ends {new Date(c.endsAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
                <Link href="/write">
                  <Button size="sm" className="rounded-xl h-8 text-xs shrink-0">
                    Enter <ArrowRight className="w-3 h-3 ml-1" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

function CommunityFeed() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getStoredToken();
    fetch('/api/feed/trending?limit=15', { headers: token ? { Authorization: `Bearer ${token}` } : {} })
      .then(r => r.ok ? r.json() : { posts: [] })
      .then(data => setPosts(data?.posts ?? []))
      .catch(() => [])
      .finally(() => setLoading(false));
  }, []);

  const reasons = [
    'Trending in your niche',
    'Popular among writing creators',
    'Rising fast this week',
    'Highly discussed today',
    'Loved by the community',
    'Top-read this week',
  ];

  return (
    <div className="space-y-5">
      {loading ? (
        Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-2xl" />)
      ) : posts.length === 0 ? (
        <div className="text-center py-20 bg-muted/20 rounded-2xl border border-dashed border-border text-muted-foreground">
          <Globe className="w-14 h-14 mx-auto mb-4 opacity-30" />
          <h3 className="text-lg font-serif font-medium mb-2">Community feed loading…</h3>
          <p className="text-sm">Follow creators and topics to personalize your feed</p>
        </div>
      ) : (
        posts.map((post: any, i: number) => (
          <div key={post.id} className="space-y-1">
            <div className="flex items-center gap-1.5 px-1 mb-1">
              <Sparkles className="w-3 h-3 text-primary" />
              <span className="text-[11px] text-muted-foreground">{reasons[i % reasons.length]}</span>
            </div>
            <PostCard post={post} />
          </div>
        ))
      )}
    </div>
  );
}

export default function Community() {
  const { user } = useAuthStore();

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto px-4 md:px-0">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="relative overflow-hidden bg-gradient-to-br from-violet-600/15 via-purple-500/8 to-transparent border border-violet-500/20 rounded-3xl p-6 md:p-8 mb-2">
            <div className="absolute top-0 right-0 w-64 h-64 bg-violet-500/5 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl pointer-events-none" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-xl bg-violet-500/20 flex items-center justify-center">
                  <Globe className="w-4 h-4 text-violet-500" />
                </div>
                <Badge className="bg-violet-500/15 text-violet-600 dark:text-violet-300 border border-violet-500/25 text-xs">
                  Platform Square
                </Badge>
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold mb-2">
                QuillHive Community
              </h1>
              <p className="text-muted-foreground max-w-lg">
                The open space where every creator belongs — no joining required. Discover trending voices, 
                participate in community challenges, and connect with creators across every niche.
              </p>
              <div className="flex flex-wrap gap-2 mt-4">
                <Link href="/write">
                  <Button size="sm" className="rounded-xl bg-violet-600 hover:bg-violet-700 text-white">
                    <Zap className="w-3.5 h-3.5 mr-1.5" /> Share Your Voice
                  </Button>
                </Link>
                <Link href="/groups">
                  <Button size="sm" variant="outline" className="rounded-xl">
                    <Users className="w-3.5 h-3.5 mr-1.5" /> Browse Groups
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          <div className="bg-card/50 border border-border/40 rounded-2xl p-3.5 flex items-start gap-3">
            <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
              <Megaphone className="w-3.5 h-3.5 text-primary" />
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              <span className="font-semibold text-foreground">Community</span> is QuillHive's open platform square — for everyone, always.{' '}
              <Link href="/groups" className="text-primary hover:underline font-medium">Groups</Link> are focused niche circles you <em>join</em> around specific topics, skills, or projects.
            </p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Tabs defaultValue="feed">
              <TabsList className="mb-6 bg-muted/50 rounded-xl p-1 w-full">
                <TabsTrigger value="feed" className="flex-1 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm text-xs">
                  <Flame className="w-3.5 h-3.5 mr-1.5" /> Trending Feed
                </TabsTrigger>
                <TabsTrigger value="spotlights" className="flex-1 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm text-xs">
                  <Star className="w-3.5 h-3.5 mr-1.5" /> Spotlights
                </TabsTrigger>
                <TabsTrigger value="challenges" className="flex-1 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm text-xs">
                  <Trophy className="w-3.5 h-3.5 mr-1.5" /> Challenges
                </TabsTrigger>
              </TabsList>
              <TabsContent value="feed">
                <CommunityFeed />
              </TabsContent>
              <TabsContent value="spotlights">
                <CreatorSpotlights />
              </TabsContent>
              <TabsContent value="challenges">
                <CommunityChallenges />
              </TabsContent>
            </Tabs>
          </div>

          <div className="hidden lg:block">
            <div className="sticky top-20 space-y-5">
              <CommunityPulse />
              <div className="bg-card border border-border/60 rounded-2xl p-5">
                <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-primary" /> Quick Links
                </h3>
                <div className="space-y-2">
                  {[
                    { href: '/explore', label: 'Discover Creators', icon: TrendingUp },
                    { href: '/groups', label: 'Browse Groups', icon: Users },
                    { href: '/challenges', label: 'All Challenges', icon: Trophy },
                    { href: '/opportunities', label: 'Opportunities', icon: Rocket },
                    { href: '/trending', label: 'Trending Content', icon: Flame },
                  ].map(({ href, label, icon: Icon }) => (
                    <Link key={href} href={href} className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-muted transition-colors text-sm text-muted-foreground hover:text-foreground">
                      <Icon className="w-4 h-4 text-primary/70" />
                      {label}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
