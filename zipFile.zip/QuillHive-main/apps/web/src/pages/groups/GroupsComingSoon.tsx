import { useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Users, Bell, Sparkles } from 'lucide-react';
import { getStoredToken } from '@/lib/api';

export default function GroupsComingSoon() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleNotify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    try {
      const token = getStoredToken();
      await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ email: email.trim(), feature: 'groups' }),
      });
      setSubmitted(true);
      toast({ title: "You're on the list!", description: "We'll notify you when Groups launches." });
    } catch {
      toast({ title: "Saved", description: "We'll notify you at launch." });
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="max-w-lg mx-auto px-4 py-16 text-center space-y-8">
        <div className="flex justify-center">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-xl shadow-violet-500/30">
            <Users className="w-12 h-12 text-white" />
          </div>
        </div>

        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 text-violet-600 dark:text-violet-400 text-xs font-semibold">
            <Sparkles className="w-3 h-3" /> Coming Soon
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Groups</h1>
          <p className="text-muted-foreground leading-relaxed max-w-sm mx-auto">
            A dedicated space where creators share work, run challenges, and grow together. Collaborate in private or public circles built around your craft.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 text-sm text-muted-foreground">
          {['Shared writing rooms', 'Creative challenges', 'Peer feedback', 'Group collab tools'].map(f => (
            <span key={f} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted">
              <span className="w-1.5 h-1.5 rounded-full bg-primary" /> {f}
            </span>
          ))}
        </div>

        {!submitted ? (
          <form onSubmit={handleNotify} className="flex gap-2 max-w-sm mx-auto">
            <Input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              className="rounded-xl"
            />
            <Button type="submit" disabled={loading} className="rounded-xl shrink-0 gap-1.5">
              <Bell className="w-4 h-4" />
              Notify me
            </Button>
          </form>
        ) : (
          <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-sm font-medium">
            ✓ You're on the waitlist
          </div>
        )}
      </div>
    </AppLayout>
  );
}
